import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";

const root = process.cwd();
const port = Number(process.env.PORT || 4321);
const host = process.env.HOST || "127.0.0.1";
const apiKey = process.env.OPENAI_API_KEY || "";
const model = process.env.OPENAI_MODEL || "gpt-5.4-nano";
const realtimeModel = process.env.OPENAI_REALTIME_MODEL || "gpt-realtime-mini";
const realtimeVoice = process.env.OPENAI_REALTIME_VOICE || "marin";

const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".webmanifest": "application/manifest+json; charset=utf-8"
};

createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, corsHeaders());
    res.end();
    return;
  }

  if (req.method === "GET" && req.url === "/api/realtime/diagnostics") {
    return handleRealtimeDiagnostics(res);
  }

  if (req.method === "POST" && req.url === "/api/realtime/call") {
    return handleRealtimeCall(req, res);
  }

  if (req.method === "POST" && req.url === "/api/chat") {
    return handleChat(req, res);
  }

  const url = new URL(req.url || "/", `http://localhost:${port}`);
  const pathname = url.pathname === "/" ? "/index.html" : url.pathname;
  const safePath = normalize(pathname).replace(/^(\.\.[/\\])+/, "");
  const filePath = join(root, safePath);

  try {
    const file = await readFile(filePath);
    res.writeHead(200, {
      "content-type": types[extname(filePath)] || "application/octet-stream"
    });
    res.end(file);
  } catch {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("Not found");
  }
}).listen(port, host, () => {
  console.log(`SpeakMate is running at http://${host}:${port}`);
  console.log(`Realtime model: ${realtimeModel}`);
  console.log(`OpenAI key present: ${apiKey ? "yes" : "no"}`);
  console.log(`Node version: ${process.version}`);
  if (!apiKey) {
    console.log("OPENAI_API_KEY is not set yet. AI chat will show a setup message.");
  }
});

async function handleRealtimeDiagnostics(res) {
  const diagnostics = {
    ok: true,
    service: "speakmate-ai-coach",
    realtimeModel,
    textModel: model,
    hasOpenAiKey: Boolean(apiKey),
    keyLooksValid: apiKey.startsWith("sk-") || apiKey.startsWith("sess-"),
    nodeVersion: process.version,
    checkedAt: new Date().toISOString()
  };

  if (!apiKey) {
    return sendJson(res, 200, {
      ...diagnostics,
      openaiReachable: false,
      message: "OPENAI_API_KEY is missing on Render."
    });
  }

  try {
    const response = await fetch(`https://api.openai.com/v1/models/${encodeURIComponent(realtimeModel)}`, {
      headers: {
        "authorization": `Bearer ${apiKey}`
      }
    });
    const data = await response.json().catch(() => ({}));
    return sendJson(res, 200, {
      ...diagnostics,
      openaiReachable: response.ok,
      openaiStatus: response.status,
      openaiModelId: data.id || null,
      openaiError: data.error?.message || null
    });
  } catch (error) {
    return sendJson(res, 200, {
      ...diagnostics,
      openaiReachable: false,
      openaiError: error.message || "OpenAI diagnostics failed."
    });
  }
}

async function handleRealtimeCall(req, res) {
  try {
    if (!apiKey) {
      res.writeHead(500, { ...corsHeaders(), "content-type": "text/plain; charset=utf-8" });
      res.end("OPENAI_API_KEY is not set on the server.");
      return;
    }

    const sdp = await readText(req, 1_000_000);
    console.log(`Realtime call requested. SDP length: ${sdp.length}. Model: ${realtimeModel}.`);
    if (!sdp.includes("v=0")) {
      res.writeHead(400, { ...corsHeaders(), "content-type": "text/plain; charset=utf-8" });
      res.end("Invalid SDP offer received by server.");
      return;
    }

    const result = await createRealtimeAnswer(sdp);
    console.log(`Realtime SDP exchange succeeded via ${result.method}. Answer length: ${result.answer.length}.`);

    res.writeHead(200, { ...corsHeaders(), "content-type": "application/sdp" });
    res.end(result.answer);
  } catch (error) {
    console.error("Realtime server error:", error);
    res.writeHead(500, { ...corsHeaders(), "content-type": "text/plain; charset=utf-8" });
    res.end(error.message || "Realtime server error");
  }
}

async function createRealtimeAnswer(sdp) {
  const attempts = [
    () => createRealtimeAnswerViaCalls(sdp),
    () => createRealtimeAnswerViaSdpEndpoint(sdp)
  ];
  const errors = [];

  for (const attempt of attempts) {
    try {
      const result = await attempt();
      if (result.answer.includes("v=0")) {
        return result;
      }
      errors.push(`${result.method}: response did not look like SDP (${result.answer.slice(0, 220)})`);
    } catch (error) {
      errors.push(error.message || String(error));
    }
  }

  throw new Error(`OpenAI Realtime SDP exchange failed. ${errors.join(" | ")}`);
}

async function createRealtimeAnswerViaCalls(sdp) {
  const form = new FormData();
  form.set("sdp", sdp);
  form.set("session", JSON.stringify({
    type: "realtime",
    model: realtimeModel,
    instructions: realtimeInstructions(),
    audio: {
      input: {
        turn_detection: {
          type: "server_vad",
          silence_duration_ms: 650
        }
      },
      output: {
        voice: realtimeVoice
      }
    }
  }));

  const response = await fetch("https://api.openai.com/v1/realtime/calls", {
    method: "POST",
    headers: {
      "authorization": `Bearer ${apiKey}`,
      "OpenAI-Safety-Identifier": "speakmate-web-user"
    },
    body: form
  });

  const text = await response.text();
  console.log(`Realtime calls endpoint status: ${response.status}. Content-Type: ${response.headers.get("content-type") || "unknown"}. Body length: ${text.length}.`);
  if (!response.ok) {
    throw new Error(`calls endpoint ${response.status}: ${text.slice(0, 600)}`);
  }

  return {
    method: "calls",
    answer: extractSdpAnswer(text)
  };
}

async function createRealtimeAnswerViaSdpEndpoint(sdp) {
  const url = new URL("https://api.openai.com/v1/realtime");
  url.searchParams.set("model", realtimeModel);
  url.searchParams.set("voice", realtimeVoice);
  url.searchParams.set("instructions", realtimeInstructions());

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "authorization": `Bearer ${apiKey}`,
      "content-type": "application/sdp",
      "OpenAI-Beta": "realtime=v1",
      "OpenAI-Safety-Identifier": "speakmate-web-user"
    },
    body: sdp
  });

  const text = await response.text();
  console.log(`Realtime SDP endpoint status: ${response.status}. Content-Type: ${response.headers.get("content-type") || "unknown"}. Body length: ${text.length}.`);
  if (!response.ok) {
    throw new Error(`sdp endpoint ${response.status}: ${text.slice(0, 600)}`);
  }

  return {
    method: "sdp-endpoint",
    answer: extractSdpAnswer(text)
  };
}

function extractSdpAnswer(text) {
  const clean = text.trim();
  if (clean.startsWith("v=0")) {
    return clean;
  }

  try {
    const json = JSON.parse(clean);
    for (const key of ["sdp", "answer", "answer_sdp"]) {
      if (typeof json[key] === "string" && json[key].includes("v=0")) {
        return json[key];
      }
    }
  } catch {}

  return clean;
}

async function handleChat(req, res) {
  try {
    if (!apiKey) {
      return sendJson(res, 500, {
        error: "OPENAI_API_KEY is not set on the server."
      });
    }

    const body = await readJson(req);
    const userMessage = String(body.message || "").slice(0, 1200);
    const mode = String(body.mode || "talk");
    const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
    const profile = typeof body.profile === "object" && body.profile ? body.profile : {};
    const memory = typeof body.memory === "object" && body.memory ? body.memory : {};
    const lesson = typeof body.lesson === "object" && body.lesson ? body.lesson : null;
    const examQuestion = typeof body.examQuestion === "object" && body.examQuestion ? body.examQuestion : null;
    const vocabulary = Array.isArray(body.vocabulary) ? body.vocabulary.slice(0, 12) : [];
    const personality = typeof body.personality === "object" && body.personality ? body.personality : {};

    const input = [
      {
        role: "user",
        content: [
          {
            type: "input_text",
            text: JSON.stringify({
              mode,
              user_message: userMessage,
              recent_history: history,
              learner_profile: profile,
              learner_memory: memory,
              lesson_context: lesson,
              exam_question: examQuestion,
              personal_vocabulary: vocabulary,
              coach_personality: personality
            })
          }
        ]
      }
    ];

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "authorization": `Bearer ${apiKey}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model,
        instructions: tutorInstructions(),
        input,
        max_output_tokens: 700,
        text: {
          format: {
            type: "json_schema",
            name: "english_tutor_reply",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              required: ["reply_en", "correction", "explanation_ru", "next_task", "speak_text", "mistake_category"],
              properties: {
                reply_en: { type: "string" },
                correction: { type: "string" },
                explanation_ru: { type: "string" },
                next_task: { type: "string" },
                speak_text: { type: "string" },
                mistake_category: { type: "string" }
              }
            }
          }
        }
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI error:", response.status, data.error?.message || data);
      return sendJson(res, response.status, {
        error: data.error?.message || "OpenAI request failed."
      });
    }

    const text = extractOutputText(data);
    const parsed = JSON.parse(text);
    return sendJson(res, 200, parsed);
  } catch (error) {
    console.error("Server error:", error);
    return sendJson(res, 500, {
      error: error.message || "Server error"
    });
  }
}

function realtimeInstructions() {
  return `
Ты — Алекс, живой, эмоциональный и поддерживающий личный учитель английского языка. Ты общаешься с пользователем исключительно голосом, имитируя телефонный звонок.

ТВОЙ СТИЛЬ РЕЧИ:
- Говори как реальный человек: используй живые интонации, легкие паузы, мягкие смешки и искренние эмоции, но не переигрывай.
- Твои реплики должны быть короткими и емкими: 1-3 предложения, чтобы поддерживать динамику звонка.

ЯЗЫКОВОЙ РЕЖИМ: АНГЛИЙСКИЙ + РУССКИЙ
- Ты в совершенстве владеешь английским и русским языками.
- Основной диалог веди на английском, подстраиваясь под уровень ученика.
- Если ученик отвечает с грубой ошибкой, мягко переключись на русский язык, объясни правило или правильный вариант одной короткой фразой, затем вернись на английский и задай следующий вопрос.
- Если ученик не знает слова и спрашивает по-русски, например "Как будет преодолеть?", тепло подскажи перевод на русском и попроси повторить фразу полностью на английском.

ПОВЕДЕНИЕ В ЗВОНКЕ:
- Начинай разговор первым: тепло поприветствуй ученика и задай один простой вопрос.
- Не говори длинными лекциями.
- Не упоминай, что ты модель или программа.
- Не выводи текстовые списки и не диктуй markdown.
- Если пользователь молчит, мягко подбодри его коротким вопросом.
`;
}

function tutorInstructions() {
  return `
Ты — Алекс, профессиональный и очень вовлекающий преподаватель английского языка.
Твоя цель — помочь ученику убрать языковой барьер и расширить словарный запас через живой диалог.

ПРАВИЛА ВЕДЕНИЯ ДИАЛОГА:
1. Инициатива всегда на твоей стороне. Ты начинаешь разговор первым: приветствуешь ученика и задаешь простой, интересный вопрос по выбранной пользователем теме.
2. Внимательно слушай или читай ответ ученика.
   - Если ответ правильный: искренне похвали его (Good job!, Excellent!) и задай следующий логичный вопрос, развивая тему.
   - Если в ответе есть ошибка: сначала мягко поправь ученика, напиши правильный вариант, кратко в одну строку объясни почему, а затем задай следующий вопрос.
3. Держи реплики короткими: не более 2-3 предложений, чтобы ученик не уставал читать и легко мог ответить.

МЕХАНИКА ЗАВЕРШЕНИЯ УРОКА (КРИТИЧЕСКИ ВАЖНО):
- Как только ученик пишет фразу в духе "на сегодня всё", "пока", "хватит" или "bye", ты останавливаешь диалог.
- Твоя задача на этом шаге: подвести итог, похвалить за работу и дать четкое ДОМАШНЕЕ ЗАДАНИЕ на завтра — список из 5 новых полезных слов или фраз по теме сегодняшнего разговора с переводом на русский.
- Напиши: "Отличная работа на сегодня! Вот твое домашнее задание на завтра. Выучи эти 5 слов: [Список]. Завтра я их проверю! Bye!"

МЕХАНИКА ПРОВЕРКИ ДЗ (НА СЛЕДУЮЩИЙ ДЕНЬ):
- При первом сообщении пользователя на следующий день или при новом сеансе ты должна помнить по recent_history, personal_vocabulary и learner_memory, либо спросить: "Привет! Готов проверить вчерашнее домашнее задание? Как переводится слово [Вставить слово из вчерашнего списка]?"
- Проведи мини-диктант по этим 5 словам, прежде чем переходить к новой теме.

Дополнительные правила приложения:
- Ответ в reply_en должен быть живой репликой Alex: английский + при необходимости короткое русское пояснение.
- correction заполняй только если есть ошибка или более естественный вариант.
- explanation_ru пиши коротко, одной строкой.
- next_task используй как следующий вопрос или задание ученику.
- speak_text должен быть короткой фразой для озвучки.
- mistake_category классифицируй как Grammar, Word order, Vocabulary, Pronunciation hint, Natural phrase или No mistake.
Do not explain your internal reasoning.
Return only valid JSON matching the schema.
`;
}

function extractOutputText(data) {
  if (typeof data.output_text === "string") {
    return data.output_text;
  }

  for (const item of data.output || []) {
    if (typeof item.text === "string") {
      return item.text;
    }

    for (const content of item.content || []) {
      if (content.type === "output_text" && content.text) {
        return content.text;
      }
      if (content.type === "text" && content.text) {
        return content.text;
      }
      if (content.type === "json_schema" && content.text) {
        return content.text;
      }
      if (typeof content === "string") {
        return content;
      }
    }
  }

  console.error("Unexpected OpenAI response:", JSON.stringify(data, null, 2));
  if (data.status === "incomplete") {
    throw new Error("OpenAI response was incomplete. Try again or use a non-reasoning chat model.");
  }
  throw new Error("No text returned from OpenAI.");
}

function readText(req, limit = 100_000) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.setEncoding("utf8");
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > limit) {
        req.destroy();
        reject(new Error("Request body is too large."));
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100_000) {
        req.destroy();
        reject(new Error("Request body is too large."));
      }
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        reject(new Error("Invalid JSON."));
      }
    });
    req.on("error", reject);
  });
}

function sendJson(res, status, value) {
  res.writeHead(status, { ...corsHeaders(), "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(value));
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "content-type,authorization"
  };
}
